MACE 1.21.5 - proyecto fuente para Beast / Minecraft 1.12.2

IMPORTANTE SOBRE LA APARIENCIA:
Minecraft 1.12.2 no tiene el objeto ni el modelo 3D de la maza de 1.21.5.
Sin un resource pack, este plugin usa un hacha de diamante como objeto base,
con el nombre visible "Mace". El resource pack puede cambiar su apariencia.

MECANICAS:
- Golpeando a un jugador desde el suelo: impulsa al atacante hacia arriba.
- Golpeando a un jugador durante una caida: añade daño segun la distancia.
- Un golpe de caida acertado evita el daño de esa caida.
- Si cae sin acertar un golpe durante la caida, recibe daño normal.
- El impulso desde el suelo tiene cooldown configurable.

COMANDO:
- /mace give
- /mace give <jugador>

PERMISO:
- mace.admin (por defecto: operadores)

COMPILACION:
Requiere Java 8 y Maven con acceso al repositorio de Spigot.
Desde esta carpeta ejecuta:
    mvn clean package

El archivo resultante será:
    target/Mace-1.21.5-1.0.0.jar

INSTALACION:
1. Compila el proyecto.
2. Sube el JAR a la carpeta plugins del servidor.
3. Reinicia el servidor.
4. Ejecuta /mace give

Este es código fuente, no un JAR ya compilado. Debe compilarse y probarse
en una copia de respaldo del servidor antes de usarlo en producción.
