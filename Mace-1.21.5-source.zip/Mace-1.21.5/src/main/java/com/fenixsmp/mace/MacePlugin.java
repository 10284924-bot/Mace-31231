package com.fenixsmp.mace;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.util.Vector;

public final class MacePlugin extends JavaPlugin implements Listener {
    private final Map<UUID, Long> groundHitCooldowns = new HashMap<UUID, Long>();
    private final Map<UUID, Long> successfulSmashes = new HashMap<UUID, Long>();

    @Override
    public void onEnable() {
        saveDefaultConfig();
        Bukkit.getPluginManager().registerEvents(this, this);
        getLogger().info("Mace 1.21.5 habilitado para Minecraft 1.12.2.");
    }

    @Override
    public void onDisable() {
        groundHitCooldowns.clear();
        successfulSmashes.clear();
    }

    private boolean isMace(ItemStack item) {
        if (item == null || item.getType() != Material.DIAMOND_AXE || !item.hasItemMeta()) {
            return false;
        }
        ItemMeta meta = item.getItemMeta();
        if (!meta.hasDisplayName()) return false;
        String expected = getConfig().getString("item-name", "Mace");
        return expected.equals(ChatColor.stripColor(meta.getDisplayName()));
    }

    private ItemStack createMace() {
        ItemStack item = new ItemStack(Material.DIAMOND_AXE, 1);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(ChatColor.WHITE + getConfig().getString("item-name", "Mace"));
        item.setItemMeta(meta);
        return item;
    }

    @EventHandler
    public void onMaceHit(EntityDamageByEntityEvent event) {
        if (!(event.getDamager() instanceof Player) || !(event.getEntity() instanceof Player)) return;

        final Player attacker = (Player) event.getDamager();
        if (!isMace(attacker.getItemInHand())) return;

        float fallDistance = attacker.getFallDistance();
        double smashThreshold = getConfig().getDouble("minimum-smash-fall-distance", 1.5);

        // Smash: falling hit. More fall distance means more bonus damage.
        if (!attacker.isOnGround() && fallDistance >= smashThreshold) {
            double extra = getConfig().getDouble("smash-base-bonus-damage", 4.0)
                    + Math.max(0.0, fallDistance - smashThreshold)
                    * getConfig().getDouble("smash-damage-per-block", 1.0);
            extra = Math.min(extra, getConfig().getDouble("maximum-smash-bonus-damage", 40.0));
            event.setDamage(event.getDamage() + extra);

            // Scaled knockback away from the attacker.
            Player target = (Player) event.getEntity();
            Vector direction = target.getLocation().toVector()
                    .subtract(attacker.getLocation().toVector());
            if (direction.lengthSquared() > 0.0001) {
                direction.normalize();
                double kb = Math.min(
                        getConfig().getDouble("maximum-smash-knockback", 1.8),
                        fallDistance * getConfig().getDouble("smash-knockback-per-block", 0.12));
                Vector current = target.getVelocity();
                target.setVelocity(current.add(direction.multiply(kb)).setY(Math.max(current.getY(), 0.35)));
            }

            // Only a successful falling hit protects the attacker from this landing's fall damage.
            successfulSmashes.put(attacker.getUniqueId(), System.currentTimeMillis() + 10000L);
            attacker.setFallDistance(0.0F);
            return;
        }

        // Ground hit: bounce the attacker upward. It does not protect them from later fall damage.
        if (attacker.isOnGround()) {
            long now = System.currentTimeMillis();
            long cooldown = getConfig().getLong("ground-hit-cooldown-seconds", 2L) * 1000L;
            Long last = groundHitCooldowns.get(attacker.getUniqueId());
            if (last != null && now - last.longValue() < cooldown) return;

            Vector velocity = attacker.getVelocity();
            velocity.setY(getConfig().getDouble("ground-hit-jump-velocity", 1.25));
            attacker.setVelocity(velocity);
            groundHitCooldowns.put(attacker.getUniqueId(), now);
        }
    }

    @EventHandler
    public void onFallDamage(EntityDamageEvent event) {
        if (!(event.getEntity() instanceof Player)) return;
        if (event.getCause() != EntityDamageEvent.DamageCause.FALL) return;

        Player player = (Player) event.getEntity();
        Long expires = successfulSmashes.get(player.getUniqueId());
        if (expires == null) return;

        if (System.currentTimeMillis() <= expires.longValue()) {
            event.setCancelled(true);
        }
        successfulSmashes.remove(player.getUniqueId());
    }

    @EventHandler
    public void onMove(PlayerMoveEvent event) {
        // Expire old successful-smash markers so they cannot affect a later unrelated fall.
        UUID id = event.getPlayer().getUniqueId();
        Long expires = successfulSmashes.get(id);
        if (expires != null && System.currentTimeMillis() > expires.longValue()) {
            successfulSmashes.remove(id);
        }
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!command.getName().equalsIgnoreCase("mace")) return false;
        if (!sender.hasPermission("mace.admin")) {
            sender.sendMessage(ChatColor.RED + "No tienes permiso.");
            return true;
        }

        if (args.length == 0 || !args[0].equalsIgnoreCase("give")) {
            sender.sendMessage(ChatColor.YELLOW + "Uso: /mace give [jugador]");
            return true;
        }

        Player target;
        if (args.length >= 2) {
            target = Bukkit.getPlayer(args[1]);
            if (target == null) {
                sender.sendMessage(ChatColor.RED + "Jugador no encontrado.");
                return true;
            }
        } else if (sender instanceof Player) {
            target = (Player) sender;
        } else {
            sender.sendMessage(ChatColor.YELLOW + "Uso desde consola: /mace give <jugador>");
            return true;
        }

        target.getInventory().addItem(createMace());
        target.sendMessage(ChatColor.GOLD + "Has recibido la Mace.");
        sender.sendMessage(ChatColor.GREEN + "Mace entregada a " + target.getName() + ".");
        return true;
    }
}
